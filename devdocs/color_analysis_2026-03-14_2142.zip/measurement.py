"""
measurement.py

Measurement pipeline for the arsenic colorimeter.

Given a new Bayer image (or one image per LED), computes the Mahalanobis
distances from the test strip to all invariant reference colors, optionally
updates the covariance with a Bayesian inverse-Wishart step using the live
reference patches, and feeds the distance-plus-temperature feature vector
to the fitted GP to obtain a concentration estimate with uncertainty.

Usage
-----
    result = measure_unknown(
        images_by_led = {
            "blue":  ImageData(...),
            "green": ImageData(...),
            "red":   ImageData(...),
        },
        hdf5_path  = "calibration.h5",
        gp_pkl_path= "calibration.gp.pkl",
        bayesian_update = True,
    )
    print(result.concentration, result.sigma, result.chi2_flags)
"""

from __future__ import annotations

import json
import logging
import pickle
from dataclasses import dataclass, field
from typing import Optional

import h5py
import numpy as np

from color_math import (
    ALL_LAYERS,
    REFERENCE_PATCH_NAMES,
    COV_STRIDE,
    normalise_vector,
    bayesian_update_covariance,
    mahalanobis_distance,
    mahalanobis_distance_squared,
    build_feature_vector,
    gp_predict,
)
from calibration import ImageData, load_image

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(message)s")

# ---------------------------------------------------------------------------
# Chi-squared outlier threshold: P(chi2_p > threshold) = 0.01
# Degrees of freedom = n_channels for the Mahalanobis distance.
# Common values: p=2 -> 9.21,  p=3 -> 11.34,  p=4 -> 13.28
# ---------------------------------------------------------------------------
from scipy.stats import chi2 as chi2_dist

CHI2_ALPHA: float = 0.01   # flag distances exceeding the 99th percentile


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class MeasurementResult:
    """
    Output of one unknown strip measurement.

    concentration : GP posterior mean  (the best-estimate value)
    sigma         : GP posterior std   (1-sigma uncertainty)
    feature_vector: the input to the GP, for logging/diagnostics
    distances     : (led_id, ref_name) -> Mahalanobis distance
    temperatures  : led_id -> LED temperature
    chi2_flags    : (led_id, ref_name) -> True if distance is a statistical outlier
    s_updated_used: True if Bayesian covariance update was applied
    extrapolation_warning: True if feature vector lies outside calibration range
    """
    concentration:          float
    sigma:                  float
    feature_vector:         np.ndarray
    distances:              dict = field(default_factory=dict)
    temperatures:           dict = field(default_factory=dict)
    chi2_flags:             dict = field(default_factory=dict)
    s_updated_used:         bool = False
    extrapolation_warning:  bool = False


# ---------------------------------------------------------------------------
# Load calibration data from HDF5
# ---------------------------------------------------------------------------

def load_calibration(
    hdf5_path: str,
) -> dict:
    """
    Load all calibration quantities needed for measurement.

    Returns a dict with keys:
        led_ids, ref_names, led_channels,
        covariances  : led_id -> {S, S_inv, Psi0, nu0, channels}
        feature_layout,
        cal_feature_matrix,
        cal_concentrations,
    """
    cal: dict = {}

    with h5py.File(hdf5_path, "r") as f:

        cfg = f["config"]
        cal["led_ids"]   = [s.decode() for s in cfg["led_ids"][:]]
        cal["ref_names"] = [s.decode() for s in cfg["ref_patch_names"][:]]
        cal["snr_threshold"] = float(cfg.attrs["snr_threshold"])

        cal["led_channels"] = {}
        for led_id in cal["led_ids"]:
            cal["led_channels"][led_id] = [
                s.decode()
                for s in cfg[f"channels_{led_id}"][:]
            ]

        cal["covariances"] = {}
        cov_g = f["covariance"]
        for led_id in cal["led_ids"]:
            if led_id not in cov_g:
                continue
            lg = cov_g[led_id]
            cal["covariances"][led_id] = {
                "S":        lg["S"][:],
                "S_inv":    lg["S_inv"][:],
                "Psi0":     lg["Psi0"][:],
                "nu0":      float(lg.attrs["nu0"]),
                "channels": [s.decode() for s in lg["channels"][:]],
            }

        gp_g = f["gp_model"]
        cal["feature_layout"]      = [s.decode()
                                       for s in gp_g["feature_layout"][:]]
        cal["cal_feature_matrix"]  = gp_g["feature_matrix"][:]
        cal["cal_concentrations"]  = gp_g["concentrations"][:]

    log.info("Calibration loaded: %d LEDs, %d ref patches, %d cal strips.",
             len(cal["led_ids"]),
             len(cal["ref_names"]),
             len(cal["cal_concentrations"]))
    return cal


# ---------------------------------------------------------------------------
# Optional Bayesian covariance update
# ---------------------------------------------------------------------------

def update_covariance_from_image(
    img:      ImageData,
    channels: list[str],
    S_cal:    np.ndarray,
    nu0:      float,
) -> np.ndarray:
    """
    Apply the inverse-Wishart Bayesian update to the calibration covariance
    using the live reference patches from this image.

    The update uses only REFERENCE_PATCH_NAMES (not SAMPLE, not BLACK),
    which are the invariant patches whose pixel noise reflects the current
    illumination and camera state.

    This is most useful when LED temperature has drifted significantly
    from the calibration conditions, causing a shift in the noise structure.
    """
    pixel_blocks: list[np.ndarray] = []
    for patch_name in REFERENCE_PATCH_NAMES:
        block = np.column_stack([
            img.patch[patch_name][layer].pixels
            for layer in ALL_LAYERS
        ])
        pixel_blocks.append(block)

    white_means = {layer: img.patch["WHITE"][layer].mean for layer in channels}

    S_updated = bayesian_update_covariance(
        S_cal        = S_cal,
        nu0          = nu0,
        pixel_blocks = pixel_blocks,
        white_means  = white_means,
        exposure     = img.exposure,
        channels     = channels,
    )

    # Check that the update did not degrade conditioning significantly.
    cond_cal     = float(np.linalg.cond(S_cal))
    cond_updated = float(np.linalg.cond(S_updated))
    if cond_updated > 10.0 * cond_cal:
        log.warning(
            "Bayesian update worsened conditioning (%.2e -> %.2e). "
            "Falling back to calibration S.",
            cond_cal, cond_updated
        )
        return S_cal.copy()

    log.debug("Bayesian S update: cond %.2e -> %.2e", cond_cal, cond_updated)
    return S_updated


# ---------------------------------------------------------------------------
# Compute distances for one measurement image
# ---------------------------------------------------------------------------

def compute_measurement_distances(
    img:           ImageData,
    channels:      list[str],
    S_inv:         np.ndarray,
    ref_names:     list[str],
) -> tuple[dict[str, float], dict[str, bool]]:
    """
    Compute the Mahalanobis distance from the SAMPLE patch to each
    reference patch.

    Also compute chi-squared outlier flags.  A distance is flagged if
    d_M^2 > chi2_{p, 1-alpha}, indicating the strip color is a statistical
    outlier relative to that reference under the current noise model.

    Returns:
        distances  : ref_name -> float
        chi2_flags : ref_name -> bool  (True = outlier)
    """
    p           = len(channels)
    chi2_thresh = chi2_dist.ppf(1.0 - CHI2_ALPHA, df=p)

    white_means = {layer: img.patch["WHITE"][layer].mean for layer in channels}

    x_sample = normalise_vector(
        patch_means = {layer: img.patch["SAMPLE"][layer].mean
                       for layer in channels},
        white_means = white_means,
        exposure    = img.exposure,
        channels    = channels,
    )

    distances:  dict[str, float] = {}
    chi2_flags: dict[str, bool]  = {}

    for ref_name in ref_names:
        x_ref = normalise_vector(
            patch_means = {layer: img.patch[ref_name][layer].mean
                           for layer in channels},
            white_means = white_means,
            exposure    = img.exposure,
            channels    = channels,
        )
        d2 = mahalanobis_distance_squared(x_sample, x_ref, S_inv)
        distances[ref_name]  = float(np.sqrt(max(d2, 0.0)))
        chi2_flags[ref_name] = bool(d2 > chi2_thresh)

        if chi2_flags[ref_name]:
            log.debug("Chi2 flag: LED=%s ref=%s d2=%.2f thresh=%.2f",
                      img.led_id, ref_name, d2, chi2_thresh)

    return distances, chi2_flags


# ---------------------------------------------------------------------------
# Extrapolation check
# ---------------------------------------------------------------------------

def check_extrapolation(
    feature_vector:  np.ndarray,
    cal_features:    np.ndarray,
) -> bool:
    """
    Warn if the measurement feature vector lies outside the convex hull
    of the calibration feature matrix (approximate check using per-feature
    range).

    A GP will extrapolate beyond its training range with increasing
    uncertainty, but an explicit flag is useful for instrument QC.
    """
    f_min = cal_features.min(axis=0)
    f_max = cal_features.max(axis=0)
    outside = np.any((feature_vector < f_min) | (feature_vector > f_max))
    if outside:
        bad_dims = np.where(
            (feature_vector < f_min) | (feature_vector > f_max)
        )[0]
        log.warning("Feature vector outside calibration range in dimensions: %s",
                    bad_dims.tolist())
    return bool(outside)


# ---------------------------------------------------------------------------
# Main measurement function
# ---------------------------------------------------------------------------

def measure_unknown(
    images_by_led:  dict[str, ImageData],
    hdf5_path:      str = "calibration.h5",
    gp_pkl_path:    str = "calibration.gp.pkl",
    bayesian_update: bool = True,
) -> MeasurementResult:
    """
    Measure the chemical concentration of an unknown test strip.

    Parameters
    ----------
    images_by_led  : dict mapping led_id -> ImageData for the unknown strip.
                     Must include all LEDs used in calibration.
    hdf5_path      : path to the calibration HDF5 file.
    gp_pkl_path    : path to the pickled GP object.
    bayesian_update: if True, update S using live reference patch pixels
                     before computing distances.

    Returns
    -------
    MeasurementResult with concentration estimate and diagnostics.
    """
    # Load calibration.
    cal = load_calibration(hdf5_path)

    with open(gp_pkl_path, "rb") as f:
        gp = pickle.load(f)

    led_ids   = cal["led_ids"]
    ref_names = cal["ref_names"]

    all_distances:  dict[tuple[str, str], float] = {}
    all_chi2_flags: dict[tuple[str, str], bool]  = {}
    temperatures:   dict[str, float]             = {}
    s_updated_used = False

    for led_id in led_ids:
        if led_id not in images_by_led:
            raise ValueError(
                f"Missing image for LED '{led_id}'.  "
                f"All calibration LEDs must be present: {led_ids}"
            )

        img      = images_by_led[led_id]
        cov      = cal["covariances"][led_id]
        channels = cov["channels"]
        S_cal    = cov["S"]
        S_inv    = cov["S_inv"]

        # Optionally update S with live reference patch noise.
        if bayesian_update:
            S_updated = update_covariance_from_image(
                img      = img,
                channels = channels,
                S_cal    = S_cal,
                nu0      = cov["nu0"],
            )
            S_inv         = np.linalg.inv(S_updated)
            s_updated_used = True

        # Compute distances from strip to every reference patch.
        dists, flags = compute_measurement_distances(
            img       = img,
            channels  = channels,
            S_inv     = S_inv,
            ref_names = ref_names,
        )

        for ref_name in ref_names:
            all_distances[(led_id, ref_name)]  = dists[ref_name]
            all_chi2_flags[(led_id, ref_name)] = flags[ref_name]

        temperatures[led_id] = img.temperature

        log.info("LED %-8s  T=%.1f  distances: %s",
                 led_id, img.temperature,
                 {r: f"{d:.4f}" for r, d in dists.items()})

    # Build feature vector.
    fv = build_feature_vector(
        distances    = all_distances,
        temperatures = temperatures,
        led_ids      = led_ids,
        ref_names    = ref_names,
    )

    # Extrapolation check.
    outside = check_extrapolation(fv, cal["cal_feature_matrix"])
    if outside:
        log.warning("Measurement feature vector is outside the calibration range. "
                    "GP prediction will extrapolate.")

    # GP prediction.
    c_hat, sigma = gp_predict(gp, fv)

    log.info("Concentration estimate: %.4f  (sigma=%.4f)", c_hat, sigma)

    return MeasurementResult(
        concentration         = c_hat,
        sigma                 = sigma,
        feature_vector        = fv,
        distances             = all_distances,
        temperatures          = temperatures,
        chi2_flags            = all_chi2_flags,
        s_updated_used        = s_updated_used,
        extrapolation_warning = outside,
    )


# ---------------------------------------------------------------------------
# Convenience wrapper: load images from filenames and measure
# ---------------------------------------------------------------------------

def measure_from_files(
    files_by_led:   dict[str, tuple],  # led_id -> (filename, led_temp, exposure, gain, timestamp)
    hdf5_path:      str = "calibration.h5",
    gp_pkl_path:    str = "calibration.gp.pkl",
    bayesian_update: bool = True,
) -> MeasurementResult:
    """
    Convenience wrapper: load ImageData objects from filenames, then measure.

    files_by_led maps each led_id to a tuple:
        (filename, led_temperature, camera_exposure, camera_gain, timestamp)
    """
    images_by_led: dict[str, ImageData] = {}

    for led_id, (filename, led_temp, exposure, gain, timestamp) in files_by_led.items():
        log.info("Loading measurement image: LED=%-8s  file=%s", led_id, filename)
        images_by_led[led_id] = load_image(
            filename    = filename,
            led_id      = led_id,
            temperature = led_temp,
            exposure    = exposure,
            gain        = gain,
            timestamp   = timestamp,
        )

    return measure_unknown(
        images_by_led   = images_by_led,
        hdf5_path       = hdf5_path,
        gp_pkl_path     = gp_pkl_path,
        bayesian_update = bayesian_update,
    )
