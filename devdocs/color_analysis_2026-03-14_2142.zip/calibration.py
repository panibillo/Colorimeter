"""
calibration.py

Calibration pipeline for the arsenic colorimeter.

Each calibration run analyzes one test strip of KNOWN chemical concentration
under all available LED conditions.  Many such runs, spanning the
concentration range of interest, build the dataset used to fit the GP.

The reference colors on the stage are invariant physical standards.
They serve as a coordinate system: every measurement is expressed as a
vector of Mahalanobis distances from the test strip to each reference color,
computed within the same image.  This makes measurements largely independent
of LED drive current and exposure time.

LED temperature IS retained as a feature because temperature shifts the LED
spectrum, which shifts color distances in a way that is not cancelled by the
within-image reference normalization.

HDF5 layout
-----------
calibration.h5
├── config/
│   ├── led_ids[]               canonical LED identifiers, ordered
│   ├── ref_patch_names[]       reference patch names used for distances
│   ├── led_channels{}          per-LED responsive layer list
│   ├── snr_threshold
│   └── feature_layout          human-readable description of feature vector
├── covariance/
│   └── {led_id}/
│       ├── S                   calibration covariance (p x p)
│       ├── S_inv
│       ├── Psi0                prior scale matrix  = nu0 * S
│       ├── nu0                 prior degrees of freedom
│       ├── channels[]          ordered channel list for this LED
│       ├── condition_number
│       └── ledoit_wolf_lambda
├── calibration_records/
│   └── {record_id}/            one group per calibration strip
│       ├── concentration       known value
│       ├── feature_vector[]    GP input (distances + temperatures)
│       ├── distances{}         (led_id, ref_name) -> distance
│       ├── temperatures{}      led_id -> temperature
│       └── image_files{}       led_id -> filename
└── gp_model/
    ├── feature_matrix          (n_cal, n_features)
    ├── concentrations[]        (n_cal,)
    ├── feature_layout[]        ordered feature names matching columns
    ├── kernel_params           fitted GP kernel parameters (JSON string)
    └── log_marginal_likelihood
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import pickle

from color_math import (
    ALL_LAYERS,
    ALL_PATCH_NAMES,
    REFERENCE_PATCH_NAMES,
    COV_STRIDE,
    normalise_vector,
    estimate_covariance_from_pixels,
    mahalanobis_distance,
    select_responsive_channels,
    build_feature_vector,
    fit_gp,
)

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(message)s")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SNR_THRESHOLD: float = 10.0
HDF5_PATH: str = "calibration.h5"

# nu0 expresses confidence in the calibration S.
# Set to the approximate number of strided pixels used in calibration.
# With 5 reference patches * 10000 pixels / stride 4 = 12500 per image,
# times however many calibration images share the same LED.
# This is computed automatically in the pipeline; set a fallback here.
NU0_FALLBACK: float = 10_000.0


# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------

@dataclass
class PatchData:
    """Statistics and raw pixels for one patch in one layer of one image."""
    mean:  float
    std:   float
    n:     int
    pixels: np.ndarray    # 1-D float64, all pixels in this patch/layer


@dataclass
class ImageData:
    """
    Everything extracted from one Bayer image.

    patch[patch_name][layer_name] = PatchData
    """
    led_id:      str
    temperature: float
    exposure:    float
    gain:        float
    filename:    str
    timestamp:   Any
    patch:       dict = field(default_factory=dict)  # patch_name -> layer -> PatchData


@dataclass
class CalibrationRecord:
    """One analyzed calibration strip with known concentration."""
    concentration: float
    images: dict = field(default_factory=dict)    # led_id -> ImageData
    # Filled in during analysis:
    distances:    dict = field(default_factory=dict)   # (led_id, ref) -> float
    temperatures: dict = field(default_factory=dict)   # led_id -> float
    feature_vector: np.ndarray = field(default_factory=lambda: np.array([]))


# ---------------------------------------------------------------------------
# Step 1 — Load one image into an ImageData structure
# ---------------------------------------------------------------------------

def load_image(
    filename: str,
    led_id: str,
    temperature: float,
    exposure: float,
    gain: float,
    timestamp: Any,
) -> ImageData:
    """
    Call get_bayer_layers() and extract per-patch, per-layer statistics
    and pixel arrays.
    """
    rects  = rect_defs()
    layers = get_bayer_layers(filename)

    img = ImageData(
        led_id=led_id,
        temperature=temperature,
        exposure=exposure,
        gain=gain,
        filename=filename,
        timestamp=timestamp,
    )

    for patch_name, rect in rects.items():
        img.patch[patch_name] = {}
        r0, r1, c0, c1 = rect
        for layer_name in ALL_LAYERS:
            arr   = layers[layer_name][r0:r1, c0:c1].astype(np.float64)
            flat  = arr.ravel()
            img.patch[patch_name][layer_name] = PatchData(
                mean   = float(flat.mean()),
                std    = float(flat.std(ddof=1)),
                n      = int(flat.size),
                pixels = flat,
            )

    return img


# ---------------------------------------------------------------------------
# Step 2 — Determine responsive channels per LED
#           (computed from ALL calibration images for that LED)
# ---------------------------------------------------------------------------

def determine_led_channels(
    all_images: list[ImageData],
    snr_threshold: float = SNR_THRESHOLD,
) -> dict[str, list[str]]:
    """
    For each LED, average the per-layer SNR across all images taken with
    that LED and select layers above the threshold.

    The channel list for each LED is fixed for all time once calibration
    is complete.  It must not change between calibration and measurement.

    Returns: led_id -> ordered list of responsive layer names.
    """
    # Accumulate per-LED, per-layer white means and black stds.
    white_acc: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))
    black_acc: dict[str, dict[str, list[float]]] = defaultdict(lambda: defaultdict(list))

    for img in all_images:
        for layer in ALL_LAYERS:
            white_acc[img.led_id][layer].append(
                img.patch["WHITE"][layer].mean)
            black_acc[img.led_id][layer].append(
                img.patch["BLACK"][layer].std)

    led_channels: dict[str, list[str]] = {}

    for led_id in sorted(white_acc.keys()):
        white_means = {layer: float(np.mean(white_acc[led_id][layer]))
                       for layer in ALL_LAYERS}
        black_stds  = {layer: float(np.mean(black_acc[led_id][layer]))
                       for layer in ALL_LAYERS}

        included, snr_vals = select_responsive_channels(
            white_means, black_stds, snr_threshold
        )
        led_channels[led_id] = included

        log.info("LED %-8s responsive channels: %s", led_id, included)
        for layer in ALL_LAYERS:
            snr = snr_vals[layer]
            flag = "OK" if layer in included else "--"
            log.info("  %s  %-4s  SNR=%6.1f", flag, layer, snr)

    return led_channels


# ---------------------------------------------------------------------------
# Step 3 — Estimate covariance per LED from all calibration images
# ---------------------------------------------------------------------------

def estimate_led_covariances(
    all_images: list[ImageData],
    led_channels: dict[str, list[str]],
) -> dict[str, dict]:
    """
    For each LED, pool reference-patch pixel arrays from all calibration
    images taken with that LED.  Estimate S with Ledoit-Wolf.

    Returns a dict:  led_id -> {
        'S', 'S_inv', 'Psi0', 'nu0',
        'lambda_lw', 'condition_number', 'channels'
    }
    """
    # Group images by LED.
    by_led: dict[str, list[ImageData]] = defaultdict(list)
    for img in all_images:
        by_led[img.led_id].append(img)

    results: dict[str, dict] = {}

    for led_id, images in sorted(by_led.items()):
        channels = led_channels[led_id]
        if not channels:
            log.warning("LED %s has no responsive channels — skipping covariance.",
                        led_id)
            continue

        # Build pixel blocks: each block is (n_pixels, n_all_layers) array.
        # We include only REFERENCE_PATCH_NAMES (not SAMPLE, not BLACK).
        pixel_blocks: list[np.ndarray] = []
        total_strided_pixels = 0

        for img in images:
            white_means = {layer: img.patch["WHITE"][layer].mean
                           for layer in channels}
            exposure    = img.exposure

            for patch_name in REFERENCE_PATCH_NAMES:
                # Stack all layers into one matrix of shape (n_px, n_all_layers).
                n_px = img.patch[patch_name][ALL_LAYERS[0]].pixels.shape[0]
                block = np.column_stack([
                    img.patch[patch_name][layer].pixels
                    for layer in ALL_LAYERS
                ])
                pixel_blocks.append(block)
                total_strided_pixels += (n_px // COV_STRIDE)

            S, lambda_lw, cond = estimate_covariance_from_pixels(
                pixel_blocks=[
                    np.column_stack([
                        img.patch[pname][layer].pixels
                        for layer in ALL_LAYERS
                    ])
                    for pname in REFERENCE_PATCH_NAMES
                ],
                white_means={layer: img.patch["WHITE"][layer].mean
                             for layer in channels},
                exposure=img.exposure,
                channels=channels,
            )

        # Re-estimate S pooling ALL images for this LED.
        all_blocks = []
        for img in images:
            for patch_name in REFERENCE_PATCH_NAMES:
                block = np.column_stack([
                    img.patch[patch_name][layer].pixels
                    for layer in ALL_LAYERS
                ])
                all_blocks.append(block)

        # Use the first image's white means and exposure as representative
        # (within a LED the white normalisation is stable).
        rep_img     = images[0]
        white_means = {layer: rep_img.patch["WHITE"][layer].mean
                       for layer in channels}

        S, lambda_lw, cond = estimate_covariance_from_pixels(
            pixel_blocks  = all_blocks,
            white_means   = white_means,
            exposure      = rep_img.exposure,
            channels      = channels,
        )

        S_inv = np.linalg.inv(S)
        nu0   = float(total_strided_pixels)
        Psi0  = nu0 * S

        results[led_id] = {
            "S":                S,
            "S_inv":            S_inv,
            "Psi0":             Psi0,
            "nu0":              nu0,
            "lambda_lw":        lambda_lw,
            "condition_number": cond,
            "channels":         channels,
        }
        log.info("LED %-8s  cov estimated  cond=%.2e  lw=%.4f  nu0=%.0f",
                 led_id, cond, lambda_lw, nu0)

    return results


# ---------------------------------------------------------------------------
# Step 4 — Compute distances for one image
# ---------------------------------------------------------------------------

def compute_distances_one_image(
    img: ImageData,
    channels: list[str],
    S_inv: np.ndarray,
) -> dict[str, float]:
    """
    Compute the Mahalanobis distance from the SAMPLE patch to each
    reference patch within this single image.

    Because both SAMPLE and each reference patch are measured in the
    SAME image under the SAME illumination, this distance is:
      - Independent of LED drive current
      - Independent of exposure time
      - Partially corrected for LED temperature (both shift together)
      - Still sensitive to LED temperature differences via the
        spectral-reflectance interaction

    Returns:  ref_patch_name -> Mahalanobis distance
    """
    white_means = {layer: img.patch["WHITE"][layer].mean for layer in channels}

    # Normalised vector for the SAMPLE patch.
    x_sample = normalise_vector(
        patch_means  = {layer: img.patch["SAMPLE"][layer].mean for layer in channels},
        white_means  = white_means,
        exposure     = img.exposure,
        channels     = channels,
    )

    distances: dict[str, float] = {}

    for ref_name in REFERENCE_PATCH_NAMES:
        x_ref = normalise_vector(
            patch_means = {layer: img.patch[ref_name][layer].mean
                           for layer in channels},
            white_means = white_means,
            exposure    = img.exposure,
            channels    = channels,
        )
        distances[ref_name] = mahalanobis_distance(x_sample, x_ref, S_inv)

    return distances


# ---------------------------------------------------------------------------
# Step 5 — Analyze one calibration strip
# ---------------------------------------------------------------------------

def analyze_calibration_strip(
    record: CalibrationRecord,
    led_channels: dict[str, list[str]],
    covariances:  dict[str, dict],
    led_ids:      list[str],
    ref_names:    list[str],
) -> None:
    """
    For each LED image in this calibration record, compute the distances
    from the SAMPLE to every reference patch.

    Populates record.distances, record.temperatures, record.feature_vector.
    Distances are keyed by (led_id, ref_name).
    """
    all_distances: dict[tuple[str, str], float] = {}
    temperatures:  dict[str, float] = {}

    for led_id, img in record.images.items():
        if led_id not in covariances:
            log.warning("No covariance for LED %s — skipping.", led_id)
            continue

        cov      = covariances[led_id]
        channels = cov["channels"]
        S_inv    = cov["S_inv"]

        dists = compute_distances_one_image(img, channels, S_inv)

        for ref_name, d in dists.items():
            all_distances[(led_id, ref_name)] = d

        temperatures[led_id] = img.temperature

    record.distances    = all_distances
    record.temperatures = temperatures
    record.feature_vector = build_feature_vector(
        distances    = all_distances,
        temperatures = temperatures,
        led_ids      = led_ids,
        ref_names    = ref_names,
    )


# ---------------------------------------------------------------------------
# Step 6 — Load all calibration data and orchestrate the pipeline
# ---------------------------------------------------------------------------

def run_calibration_pipeline() -> None:
    """
    Full calibration pipeline:
      1. Load all calibration images.
      2. Determine responsive channels per LED.
      3. Estimate covariance matrices per LED.
      4. For each calibration record, compute distance features.
      5. Fit the GP.
      6. Save to HDF5.
    """
    log.info("=== Calibration pipeline start ===")

    raw_data = get_calibration_data()
    # raw_data is a list of:
    # (concentration, filename, led_id, led_temperature,
    #  camera_exposure, camera_gain, timestamp)

    # Group entries by (concentration, led_id) to reconstruct per-strip records.
    # We assume each strip has exactly one image per LED.
    # Key: concentration value (used as a proxy strip ID).
    # If multiple strips have the same concentration, use a running index.

    # Build a unique strip_id for each group of LED images that belong together.
    # Strategy: group by (concentration, set of images captured close in time).
    # Simple approach: sort by timestamp and group consecutive LED images.
    # Here we use concentration + file index ordering as the grouping key.

    # Collect all images first.
    all_images: list[ImageData] = []
    raw_by_strip: dict[int, list[tuple]] = defaultdict(list)

    # Assign strip IDs: entries with the same concentration that were captured
    # in the same session belong together.  We identify sessions by sorting on
    # timestamp and grouping into blocks of len(unique_led_ids) entries.
    raw_data_sorted = sorted(raw_data, key=lambda r: (str(r[6]), r[0]))
    # Determine number of LEDs from the data.
    unique_leds = sorted({r[2] for r in raw_data_sorted})
    n_leds      = len(unique_leds)
    log.info("LEDs found in calibration data: %s", unique_leds)

    # Group into strips: consecutive blocks of n_leds entries.
    n_strips = len(raw_data_sorted) // n_leds
    if len(raw_data_sorted) % n_leds != 0:
        log.warning(
            "Total images (%d) not evenly divisible by n_leds (%d). "
            "Trailing images will be ignored.",
            len(raw_data_sorted), n_leds
        )

    cal_records: list[CalibrationRecord] = []

    for strip_idx in range(n_strips):
        block = raw_data_sorted[strip_idx * n_leds : (strip_idx + 1) * n_leds]

        # All entries in this block should share the same concentration.
        concentrations_in_block = {r[0] for r in block}
        if len(concentrations_in_block) > 1:
            log.warning("Strip %d has mixed concentrations: %s — using first.",
                        strip_idx, concentrations_in_block)
        concentration = block[0][0]

        rec = CalibrationRecord(concentration=float(concentration))

        for (conc, filename, led_id, led_temp,
             exposure, gain, timestamp) in block:

            img = load_image(
                filename    = filename,
                led_id      = led_id,
                temperature = led_temp,
                exposure    = exposure,
                gain        = gain,
                timestamp   = timestamp,
            )
            rec.images[led_id] = img
            all_images.append(img)

        cal_records.append(rec)

    log.info("Loaded %d calibration strips, %d total images.",
             len(cal_records), len(all_images))

    # 2. Determine responsive channels per LED.
    led_channels = determine_led_channels(all_images, SNR_THRESHOLD)

    # 3. Estimate per-LED covariance matrices.
    covariances = estimate_led_covariances(all_images, led_channels)

    # Canonical ordering for feature vector construction.
    led_ids   = sorted(covariances.keys())
    ref_names = list(REFERENCE_PATCH_NAMES)

    feature_layout = (
        [f"dist_{led}_{ref}" for led in led_ids for ref in ref_names]
        + [f"temp_{led}"     for led in led_ids]
    )
    log.info("Feature vector layout (%d features): %s",
             len(feature_layout), feature_layout)

    # 4. Compute distance features for every calibration record.
    for rec in cal_records:
        analyze_calibration_strip(rec, led_channels, covariances,
                                  led_ids, ref_names)

    # 5. Fit GP.
    feature_matrix = np.vstack([r.feature_vector for r in cal_records])
    concentrations = np.array([r.concentration   for r in cal_records])

    n_dist_features = len(led_ids) * len(ref_names)
    n_temp_features = len(led_ids)

    gp = fit_gp(
        feature_matrix      = feature_matrix,
        concentrations      = concentrations,
        n_distance_features = n_dist_features,
        n_temp_features     = n_temp_features,
    )

    # 6. Save to HDF5.
    save_calibration_hdf5(
        path            = HDF5_PATH,
        led_ids         = led_ids,
        ref_names       = ref_names,
        led_channels    = led_channels,
        covariances     = covariances,
        cal_records     = cal_records,
        feature_matrix  = feature_matrix,
        concentrations  = concentrations,
        feature_layout  = feature_layout,
        gp              = gp,
    )

    log.info("=== Calibration pipeline complete ===")


# ---------------------------------------------------------------------------
# Step 7 — Save HDF5
# ---------------------------------------------------------------------------

def save_calibration_hdf5(
    path:           str,
    led_ids:        list[str],
    ref_names:      list[str],
    led_channels:   dict[str, list[str]],
    covariances:    dict[str, dict],
    cal_records:    list[CalibrationRecord],
    feature_matrix: np.ndarray,
    concentrations: np.ndarray,
    feature_layout: list[str],
    gp,
) -> None:

    with h5py.File(path, "w") as f:
        f.attrs["description"] = (
            "Arsenic colorimeter calibration.  "
            "One covariance group per LED.  "
            "One record group per calibration strip."
        )

        # --- config ---
        cfg = f.create_group("config")
        cfg.create_dataset("led_ids",
                           data=np.array(led_ids,   dtype="S32"))
        cfg.create_dataset("ref_patch_names",
                           data=np.array(ref_names, dtype="S32"))
        cfg.attrs["snr_threshold"] = SNR_THRESHOLD
        cfg.attrs["feature_layout"] = str(feature_layout)
        for led_id in led_ids:
            cfg.create_dataset(f"channels_{led_id}",
                               data=np.array(led_channels.get(led_id, []),
                                             dtype="S8"))

        # --- covariance ---
        cov_g = f.create_group("covariance")
        for led_id, cov in covariances.items():
            lg = cov_g.create_group(led_id)
            lg.create_dataset("S",        data=cov["S"],    compression="gzip")
            lg.create_dataset("S_inv",    data=cov["S_inv"],compression="gzip")
            lg.create_dataset("Psi0",     data=cov["Psi0"], compression="gzip")
            lg.attrs["nu0"]               = cov["nu0"]
            lg.attrs["lambda_lw"]         = cov["lambda_lw"]
            lg.attrs["condition_number"]  = cov["condition_number"]
            lg.create_dataset("channels",
                              data=np.array(cov["channels"], dtype="S8"))

        # --- calibration records ---
        rec_g = f.create_group("calibration_records")
        for idx, rec in enumerate(cal_records):
            rg = rec_g.create_group(f"strip_{idx:04d}")
            rg.attrs["concentration"]  = rec.concentration
            rg.create_dataset("feature_vector", data=rec.feature_vector)

            # Distances: store as a matrix (n_leds * n_refs,) with labels.
            dist_keys   = sorted(rec.distances.keys(),
                                 key=lambda k: (k[0], k[1]))
            dist_labels = [f"{led}_{ref}" for led, ref in dist_keys]
            dist_values = np.array([rec.distances[k] for k in dist_keys])
            rg.create_dataset("distance_values", data=dist_values)
            rg.create_dataset("distance_labels",
                              data=np.array(dist_labels, dtype="S64"))

            temp_keys   = sorted(rec.temperatures.keys())
            rg.create_dataset("temperature_values",
                              data=np.array([rec.temperatures[k]
                                             for k in temp_keys]))
            rg.create_dataset("temperature_labels",
                              data=np.array(temp_keys, dtype="S32"))

            for led_id, img in rec.images.items():
                rg.attrs[f"file_{led_id}"] = img.filename

        # --- GP model ---
        gp_g = f.create_group("gp_model")
        gp_g.create_dataset("feature_matrix",
                            data=feature_matrix, compression="gzip")
        gp_g.create_dataset("concentrations",    data=concentrations)
        gp_g.create_dataset("feature_layout",
                            data=np.array(feature_layout, dtype="S64"))
        gp_g.attrs["log_marginal_likelihood"] = gp.log_marginal_likelihood_value_
        gp_g.attrs["kernel_params"] = json.dumps(
            {p: float(v)
             for p, v in gp.kernel_.get_params().items()
             if isinstance(v, (int, float))}
        )
        # Also pickle the fitted GP object alongside the HDF5 for reuse.
        pickle_path = Path(path).with_suffix(".gp.pkl")
        with open(pickle_path, "wb") as pf:
            pickle.dump(gp, pf)
        log.info("GP object pickled to %s", pickle_path)

    log.info("HDF5 written to %s", path)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run_calibration_pipeline()
