"""
color_math.py

Shared mathematical routines for the arsenic colorimeter.

All colour vectors are expressed in normalised Bayer-layer space.
Normalisation:  x_norm[k] = raw_mean[k] / (exposure * white_mean[k])

This makes vectors dimensionless and removes LED drive-current and
exposure-time variation.  Temperature-induced spectral drift is NOT
removed by normalisation — it appears as a smooth continuous covariate
in the GP regression.
"""

from __future__ import annotations

import logging
from typing import Sequence

import numpy as np
from sklearn.covariance import LedoitWolf
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Bayer layers in a fixed, consistent order.
ALL_LAYERS: tuple[str, ...] = ("B", "Gb", "Gr", "R")

# Reference patch names used for covariance estimation and distance
# computation.  WHITE is used for normalisation; BLACK is excluded from
# covariance estimation because near-zero values distort the normalised
# ratios.
REFERENCE_PATCH_NAMES: tuple[str, ...] = ("WHITE", "YELLOW1", "YELLOW2", "BROWN", "RED")

ALL_PATCH_NAMES: tuple[str, ...] = (
    "WHITE", "YELLOW1", "YELLOW2", "BROWN", "RED", "SAMPLE", "BLACK"
)

# Pixel stride for covariance estimation (reduces spatial autocorrelation).
COV_STRIDE: int = 4


# ---------------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------------

def normalise_patch_mean(
    raw_mean: float,
    white_mean: float,
    exposure: float,
) -> float:
    """
    Normalised value for a single channel of a single patch.

        x_norm = raw_mean / (exposure * white_mean)

    Returns 0.0 if white_mean is zero (non-responsive channel guard).
    """
    denom = exposure * white_mean
    return raw_mean / denom if denom > 0.0 else 0.0


def normalise_vector(
    patch_means: dict[str, float],   # layer -> raw mean for this patch
    white_means: dict[str, float],   # layer -> raw mean for WHITE patch
    exposure: float,
    channels: list[str],
) -> np.ndarray:
    """
    Return the normalised N-channel colour vector for one patch.

    channels defines both which layers to include and their order.
    """
    return np.array([
        normalise_patch_mean(patch_means[layer], white_means[layer], exposure)
        for layer in channels
    ], dtype=np.float64)


# ---------------------------------------------------------------------------
# Covariance estimation
# ---------------------------------------------------------------------------

def estimate_covariance_from_pixels(
    pixel_blocks: list[np.ndarray],
    white_means: dict[str, float],
    exposure: float,
    channels: list[str],
    stride: int = COV_STRIDE,
    extra_ridge: bool = False,
    ridge_alpha: float = 1e-3,
) -> tuple[np.ndarray, float, float]:
    """
    Estimate the within-patch covariance matrix from raw pixel arrays.

    pixel_blocks : list of (n_pixels, n_all_layers) arrays, one per
                   reference patch.  Columns are in ALL_LAYERS order.
    white_means  : layer -> white patch mean (for normalisation).
    channels     : ordered subset of ALL_LAYERS to include.

    Returns:
        S           (n_ch, n_ch) Ledoit-Wolf covariance estimate
        lambda_lw   shrinkage coefficient
        condition_number
    """
    layer_indices = {layer: ALL_LAYERS.index(layer) for layer in channels}
    denom = {layer: exposure * white_means[layer] for layer in channels}

    obs_rows: list[np.ndarray] = []
    for block in pixel_blocks:
        # block shape: (n_pixels,) for each layer stored separately, or
        # we build a (n_pixels_strided, n_ch) matrix.
        strided = block[::stride, :]          # (n_strided, n_all_layers)
        normed  = np.column_stack([
            strided[:, layer_indices[layer]] / denom[layer]
            if denom[layer] > 0.0
            else np.zeros(strided.shape[0])
            for layer in channels
        ])
        obs_rows.append(normed)

    all_obs = np.vstack(obs_rows)

    lw        = LedoitWolf(assume_centered=False)
    lw.fit(all_obs)
    S         = lw.covariance_.copy()
    lambda_lw = float(lw.shrinkage_)

    if extra_ridge:
        S += ridge_alpha * np.eye(S.shape[0])

    cond = float(np.linalg.cond(S))
    return S, lambda_lw, cond


def bayesian_update_covariance(
    S_cal: np.ndarray,
    nu0: float,
    pixel_blocks: list[np.ndarray],
    white_means: dict[str, float],
    exposure: float,
    channels: list[str],
    stride: int = COV_STRIDE,
) -> np.ndarray:
    """
    Inverse-Wishart Bayesian update of the calibration covariance S_cal.

    Prior:   S ~ IW(Psi_0, nu_0)   with  Psi_0 = nu_0 * S_cal
             so that  E[S_prior] = S_cal.

    Likelihood: n_live new pixel observations from the live image's
                reference patches.

    Posterior mean:
        S_updated = (Psi_0 + A_live) / (nu_0 + n_live - p - 1)

    where A_live is the pooled scatter matrix from the live pixels and
    p is the number of channels.

    Parameters
    ----------
    S_cal  : calibration covariance  (p x p)
    nu0    : prior degrees of freedom  (set to total calibration pixels
             used divided by stride, to reflect confidence in S_cal)
    pixel_blocks, white_means, exposure, channels, stride :
             same semantics as estimate_covariance_from_pixels()

    Returns
    -------
    S_updated : (p x p)  posterior mean covariance
    """
    p = len(channels)
    Psi0 = nu0 * S_cal

    layer_indices = {layer: ALL_LAYERS.index(layer) for layer in channels}
    denom         = {layer: exposure * white_means[layer] for layer in channels}

    A_live   = np.zeros((p, p))
    n_live   = 0

    for block in pixel_blocks:
        strided = block[::stride, :]
        normed  = np.column_stack([
            strided[:, layer_indices[layer]] / denom[layer]
            if denom[layer] > 0.0
            else np.zeros(strided.shape[0])
            for layer in channels
        ])
        mu      = normed.mean(axis=0, keepdims=True)
        centred = normed - mu
        A_live += centred.T @ centred
        n_live += normed.shape[0]

    nu_post  = nu0 + n_live
    Psi_post = Psi0 + A_live
    denom_iw = nu_post - p - 1

    if denom_iw <= 0:
        log.warning(
            "Inverse-Wishart denominator <= 0 (nu_post=%d, p=%d). "
            "Returning calibration S unchanged.", nu_post, p
        )
        return S_cal.copy()

    S_updated = Psi_post / denom_iw
    log.debug("Bayesian S update: nu0=%.0f  n_live=%d  nu_post=%.0f",
              nu0, n_live, nu_post)
    return S_updated


# ---------------------------------------------------------------------------
# Mahalanobis distance
# ---------------------------------------------------------------------------

def mahalanobis_distance(
    x_strip: np.ndarray,
    x_ref: np.ndarray,
    S_inv: np.ndarray,
) -> float:
    """
    Mahalanobis distance between two normalised colour vectors.

        d_M = sqrt( (x_strip - x_ref)^T  S_inv  (x_strip - x_ref) )

    Both vectors must be expressed in the same normalised channel space
    and S_inv must be the inverse of the covariance for that space.
    """
    delta = x_strip - x_ref
    d2    = float(delta @ S_inv @ delta)
    # Guard against tiny negative values from floating-point errors.
    return float(np.sqrt(max(d2, 0.0)))


def mahalanobis_distance_squared(
    x_strip: np.ndarray,
    x_ref: np.ndarray,
    S_inv: np.ndarray,
) -> float:
    """Return the squared Mahalanobis distance (chi-squared distributed)."""
    delta = x_strip - x_ref
    return float(delta @ S_inv @ delta)


# ---------------------------------------------------------------------------
# SNR channel selection
# ---------------------------------------------------------------------------

def compute_snr(
    white_mean: float,
    black_std: float,
) -> float:
    """SNR = white_mean / black_std.  Returns 0 if black_std <= 0."""
    return white_mean / black_std if black_std > 0.0 else 0.0


def select_responsive_channels(
    white_means: dict[str, float],
    black_stds:  dict[str, float],
    snr_threshold: float,
) -> tuple[list[str], dict[str, float]]:
    """
    Return the ordered list of layers whose SNR meets the threshold,
    and a dict of all SNR values.

    Ordering follows ALL_LAYERS so channel vectors are always consistent.
    """
    snr_values: dict[str, float] = {}
    included:   list[str]        = []

    for layer in ALL_LAYERS:
        snr = compute_snr(white_means.get(layer, 0.0),
                          black_stds.get(layer, 0.0))
        snr_values[layer] = snr
        if snr >= snr_threshold:
            included.append(layer)

    return included, snr_values


# ---------------------------------------------------------------------------
# Feature vector construction
# ---------------------------------------------------------------------------

def build_feature_vector(
    distances: dict[tuple[str, str], float],   # (led_id, ref_name) -> distance
    temperatures: dict[str, float],            # led_id -> temperature
    led_ids: list[str],
    ref_names: list[str],
) -> np.ndarray:
    """
    Assemble the GP input feature vector from distance measurements and
    LED temperatures.

    Layout:  [ d(led_0,ref_0), d(led_0,ref_1), ..., d(led_I,ref_J),
               T_led_0, T_led_1, ..., T_led_I ]

    led_ids and ref_names define the canonical ordering and must be
    identical between calibration and measurement.
    """
    dist_features = [
        distances[(led, ref)]
        for led in led_ids
        for ref in ref_names
    ]
    temp_features = [temperatures[led] for led in led_ids]
    return np.array(dist_features + temp_features, dtype=np.float64)


# ---------------------------------------------------------------------------
# Gaussian Process regression
# ---------------------------------------------------------------------------

def build_gp_kernel(n_distance_features: int, n_temp_features: int) -> object:
    """
    Construct a GP kernel suited to the concentration interpolation problem.

    Distance features and temperature features are given separate length
    scales so the GP can learn that temperature is a smoother covariate
    than distance.

    Kernel:
        C * RBF(length_scales_dist) * RBF(length_scales_temp)
        + WhiteKernel (observation noise)
    """
    ls_dist = np.ones(n_distance_features)
    ls_temp = np.ones(n_temp_features)

    kernel = (
        ConstantKernel(1.0, (1e-3, 1e3))
        * RBF(length_scale=ls_dist,
              length_scale_bounds=[(1e-3, 1e3)] * n_distance_features)
        * RBF(length_scale=ls_temp,
              length_scale_bounds=[(1e-2, 1e2)] * n_temp_features)
        + WhiteKernel(noise_level=1e-2, noise_level_bounds=(1e-6, 1e1))
    )
    return kernel


def fit_gp(
    feature_matrix: np.ndarray,   # (n_cal, n_features)
    concentrations: np.ndarray,   # (n_cal,)
    n_distance_features: int,
    n_temp_features: int,
    n_restarts: int = 5,
) -> GaussianProcessRegressor:
    """
    Fit a Gaussian Process regressor mapping feature vectors to
    chemical concentration.

    n_restarts optimizer restarts help avoid local optima in the
    log-marginal-likelihood landscape.
    """
    kernel = build_gp_kernel(n_distance_features, n_temp_features)

    gp = GaussianProcessRegressor(
        kernel=kernel,
        n_restarts_optimizer=n_restarts,
        normalize_y=True,          # important: centres the target
        alpha=0.0,                 # noise handled by WhiteKernel
    )
    gp.fit(feature_matrix, concentrations)

    log.info("GP fitted.  Log-marginal-likelihood: %.3f",
             gp.log_marginal_likelihood_value_)
    return gp


def gp_predict(
    gp: GaussianProcessRegressor,
    feature_vector: np.ndarray,   # (n_features,)
) -> tuple[float, float]:
    """
    Predict concentration and its standard deviation for one feature vector.

    Returns (c_hat, sigma_hat).
    """
    f = feature_vector.reshape(1, -1)
    c_hat, sigma = gp.predict(f, return_std=True)
    return float(c_hat[0]), float(sigma[0])
